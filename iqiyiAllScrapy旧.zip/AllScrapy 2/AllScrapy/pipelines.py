# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy import Request
from scrapy.exceptions import DropItem
from scrapy.pipelines.images import ImagesPipeline
from twisted.enterprise import adbapi
import hashlib
import time
#通过get_project_settings来获取settings.py文件中设置的变量
from scrapy.utils.project import get_project_settings
import oss2

from AllScrapy.items import CateGroyMovieItem, MovieTableItem, MovieDetailTableItem, MoviePerformerItem, \
    PerformerDetailTableItem

xx=None
#基础类
class RootPipline(object):
    def open_spider(self,spider):
        ##读取settings中的配置信息
        db= spider.settings['DATABASE']
        host=spider.settings['HOST']
        port=spider.settings['PORT']
        user=spider.settings['USERNAME']
        passwd=spider.settings['PASSWORD']
        #第一个参数是使用mysql.connector模块连接  utf8，如果使用utf-8报错
        self.dbpool=adbapi.ConnectionPool('mysql.connector',host=host,db=db,user=user,passwd=passwd,charset='utf8')
        global xx
        xx=self.dbpool
    def close_spider(self,spider):
        self.dbpool.close()
class AllscrapyPipeline(object):
    def process_item(self, item, spider):
        print(item)
        return item
class CateGroyPipeLine(RootPipline):
    def process_item(self, item, spider):
        if isinstance(item, CateGroyMovieItem):
            self.dbpool.runInteraction(self.cateGroyAdd, item)
        return item
    def cateGroyAdd(self, tx, item):
        # 进行查询操作
        result = selectSQL(tx, "select * from categroyMovieTable where title ='%s'" % (item['title']))
        if result != None and len(result) != 0:
            return False
        # 执行插入操作
        sqlstr = "insert into categroyMovieTable(categroy,title,source) values('%s','%s','%s')" % (item['categroy'], item['title'], item['source'])
        return executeSQL(tx,sqlstr)

class MoviePipeLine(RootPipline):
    def process_item(self, item, spider):
        if isinstance(item, MovieTableItem):
            # 执行插入操作
            score = item['score']
            if score == None or score=='':
                item['score'] = '0'
            url=item['imagePath']
            if url != None and len(url)>0:
                #判断地址合法性
                if not url.startswith('http'):
                    item['imagePath']='http:'+item['imagePath']
            #处理保存地址
            item['saveImagePath']='movie/'+makeMD5(item['imagePath'])+'.jpg'
            self.dbpool.runInteraction(self.movieAdd, item)
        return item
    def movieAdd(self, tx, item):
        # 进行查询操作
        result = selectSQL(tx, "select * from movietable where moviename ='%s' and source='%s'" % (item['movieName'],item['source']))
        if result != None and len(result) != 0:
            return False

        sqlstr = "insert into movietable(id,moviename,time,url,imagepath,saveimagepath,score,source) values('%s','%s','%s','%s','%s','%s','%f','%s')" % (
            item['id'],item['movieName'], item['time'], item['url'], item['imagePath'], item['saveImagePath'],
            float(item['score']), item['source'])
        return executeSQL(tx,sqlstr)

class MovieDetailPipeLine(RootPipline):
    def process_item(self, item, spider):
        if isinstance(item, MovieDetailTableItem):
            self.dbpool.runInteraction(self.movieDetailAdd, item)
        return item
    def movieDetailAdd(self, tx, item):
        result = selectSQL(tx, "select * from moviedetailtable where id ='%s'" % (item['id']))
        if result != None and len(result) != 0:
            return False
        sqlstr = "INSERT into moviedetailtable() VALUES ('%s','%s','%s','%s','%s')" % (
            item['id'], item['director'], item['keyword'], item['categroy'], item['des'])
        return executeSQL(tx,sqlstr)

class MoviePerformerPipeLine(RootPipline):
    def process_item(self, item, spider):
        if isinstance(item, MoviePerformerItem):
            self.dbpool.runInteraction(self.moviePerformerAdd, item)
        return item
    def moviePerformerAdd(self, tx, item):
        result = selectSQL(tx, "select * from movieperformertable where id ='%s'" % (item['id']))
        if result != None and len(result) != 0:
            return False
        sqlstr = "insert into movieperformertable() values('%s','%s','%s')" % (item['id'], item['performer'], item['role'])
        return executeSQL(tx,sqlstr)

class PerformerDetailPipeLine(RootPipline):
    def process_item(self, item, spider):
        if isinstance(item, PerformerDetailTableItem):
            item['saveImagePath']='movie/'+makeMD5(item['imagePath'])+'.jpg'
            self.dbpool.runInteraction(self.performerDetailAdd, item)
        return item
    def performerDetailAdd(self, tx, item):
        result = selectSQL(tx, "select * from performerdetailtable where name ='%s'" % (item['name']))
        if result != None and len(result) != 0:
            return False
        sqlstr = "insert into performerdetailtable() values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')" \
                 % (item['name'],item['e_name'],item['sex'],item['height'],item['birthday'],
                    item['location'],item['school'],item['fameyear'],item['alias'],
                    item['bloodtype'],item['address'],item['constellation'],
                    item['ResidentialAddress'],item['BrokerageAgency'],
                    item['hobby'],item['Occupation'],item['weight'],item['imagePath'],item['des'])

        return executeSQL(tx,sqlstr)

#处理图片下载
class DownloadPipeline(ImagesPipeline):
    #定义路径和文件名
    #指定请求
    def get_media_requests(self, item, info):
        if isinstance(item, (PerformerDetailTableItem,MovieTableItem)):
            yield Request(item['imagePath'],meta={'item':item})
    def file_path(self, request, response=None, info=None):
        if request.meta['item'] !=None:
            model = request.meta['item']
            if isinstance(model, (PerformerDetailTableItem,MovieTableItem)):
                IMAGES_STORE = get_project_settings().get('HEADERIMAGE')
                path=''+IMAGES_STORE+model['saveImagePath']
                return path
        #获得下载结果
    def item_completed(self, results, item, info):
        if isinstance(item, (PerformerDetailTableItem,MovieTableItem)):
            image_paths = [x['path'] for ok, x in results if ok]      # ok判断是否下载成功
            print(image_paths)
            if not image_paths:
                print("抛出错误")
                raise DropItem("Item contains no images")
            #item['image_paths'] = image_paths
            #跳转请求，到更新数据库
        return item

class AliyunOSSPipline(RootPipline):
    #初始化阿里云
    bucket=None
    def open_spider(self,spider):
        # #初始化父类
        super(AliyunOSSPipline, self).open_spider(spider)
        # #初始化阿里云get_project_settings().get('HEADERIMAGE')
        AccessKeyId=get_project_settings().get('ACCESSKEYID')
        AccessKeySecret=get_project_settings().get('ACCESSKEYSECRET')
        #根据地域进行修改
        Endpoint=get_project_settings().get('ENDPOINT')
        bucket=get_project_settings().get('BUCKET')
        if AccessKeyId !='':
            auth = oss2.Auth(AccessKeyId, AccessKeySecret)
            self.bucket=oss2.Bucket(auth, Endpoint, bucket)

    def process_item(self, item, spider):
        #如果初始化不成功，就跳转到本地存储
        if self.bucket == None:
            return item
        import requests
        if isinstance(item, (PerformerDetailTableItem,MovieTableItem)):
            pagenum=0
            input = requests.get(item['imagePath'])
            result = self.bucket.put_object(item['saveImagePath'], input)
            print(result.status)
            if result.status==200:
                print("上传成功")

#工具封装
def executeSQL(tx,sql):
    try:
        tx.execute(sql)
        return True
    except:
        return False
def selectSQL(tx,sql):
    try:
        tx.execute(sql)
        result = tx.fetchall()
        return result
    except:
        print("出错")
        return None
def makeMD5(str):
    m = hashlib.md5()
    m.update(str.encode('UTF-8'))
    return  m.hexdigest()




