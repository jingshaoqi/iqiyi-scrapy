# -*- coding: utf-8 -*-
import scrapy
import requests
import time
from scrapy import Request
from scrapy import spider
from scrapy.selector import Selector

from scrapy.utils.project import get_project_settings

from AllScrapy.items import CateGroyMovieItem, MovieTableItem, MovieDetailTableItem, MoviePerformerItem, \
    PerformerDetailTableItem


class MmonlySpider(scrapy.Spider):
    name = 'iqiyi'
    allowed_domains = ['iqiyi.com']
    start_urls = [get_project_settings().get('CATEGROYURL')]
    def parse(self, response):
        #获得分类
        categroys=response.xpath("//div[contains(@class, 'mod_sear_list')]")[:-1]
        for i in categroys:
            cate=i.xpath("./h3/text()").extract_first().replace('：','')
            print(cate)
            #遍历其中的小标签
            titles=i.xpath(".//a/text()").extract()
            #组装模型
            for title in titles:
                item=CateGroyMovieItem()
                item['title']=title
                item['categroy']=cate
                item['source']='iqiyi'
                yield item
        #抓取电影 当前页循环30页
        # http://list.iqiyi.com/www/1/-------------1-3-1-iqiyi--.html
        for i in range(1,31):
            yield Request('http://list.iqiyi.com/www/1/-------------1-'+str(i)+'3-1-iqiyi--.html',callback=self.movielist)


    def movielist(self,respose):
        #解析电影
        #movieName、url、time、score、imagePath、source、id、saveImagePath
        #电影名称
        movielist_ele=respose.xpath("//ul[@class='site-piclist site-piclist-180236 site-piclist-auto']//li")
        for item in movielist_ele:
            model=MovieTableItem()
            model['movieName']= item.xpath("./div[@class='site-piclist_pic']/a/@title").extract_first()
            model['url']=item.xpath("./div[@class='site-piclist_pic']/a/@href").extract_first()
            model['time']=item.xpath("normalize-space(./div[@class='site-piclist_pic']//span[@class='icon-vInfo']/text())").extract_first()
            model['score']=item.xpath("string(./div[@class='site-piclist_info']//span[@class='score'])").extract_first()
            model['imagePath']=item.xpath("./div[@class='site-piclist_pic']/a/img/@src").extract_first()
            model['id'] = str(int(time.time() * 1000)) + str(int(time.clock() * 1000000))
            model['source']='iqiyi'
            yield model
            #请求电影详情页
            yield Request(model['url'],meta={'model':model},callback=self.moviedetail)

    def moviedetail(self,respose):
        #电影模型
        moviemodel=respose.meta['model']
        #电影介绍
        moviedes=respose.xpath("normalize-space(//*[@id='datainfo-tag-desc']/text())").extract_first()
        #电影关键词
        movieid=respose.xpath("//*[@id='data-videopoint']/@data-qipuid").extract_first()
        jsonstr=requests.get("http://qiqu.iqiyi.com/apis/video/tags/get?entity_id="+str(movieid)+"&limit=10").text
        import json
        jsonObject = json.loads(jsonstr)
        # 读取data,遍历 获得热词
        keyword = ''
        for object in jsonObject['data']:
            # 读取元素tag
            keyword = keyword + ',' + object['tag']
        if len(keyword) > 0:
            keyword = keyword[1:len(keyword)]
        #提取分类
        catelist=respose.xpath("//span[@class='mod-tags_item']/a/text()").extract()
        catestr=','.join(catelist)
        #提取导演、主演a标签  ",".join拼接
        list =respose.xpath("//p[@class='progInfo_rtp']")
        #导演列表
        directorlist=list[0].xpath("./span[@class='type-con']/a/text()").extract()
        #提取导演地址
        for url in list[0].xpath("./span[@class='type-con']/a/@href").extract():
            #处理地址
            if url != None and len(url)>0:
                #判断地址合法性
                if not url.startswith('http'):
                    yield Request('http:'+url,callback=self.performerdetail)
                else:
                    yield Request(url,callback=self.performerdetail)        #主演列表
        performerlist=list[1].xpath("./span[@class='type-con']/a/text()").extract()
        for url in list[1].xpath("./span[@class='type-con']/a/@href").extract():
            if url != None and len(url)>0:
                #判断地址合法性
                if not url.startswith('http'):
                    yield Request('http:'+url,callback=self.performerdetail)
                else:
                    yield Request(url,callback=self.performerdetail)

        #饰演角色
        rolelist=list[1].xpath(".//span[@class='type-con_div']/text()").extract()
        directorstr=','.join(directorlist)
        model=MovieDetailTableItem()
        model['id']=moviemodel['id']
        model['director']=directorstr
        model['keyword']=keyword
        model['categroy']=catestr
        model['des']=moviedes.replace("'",' ')
        yield model
        for index,performer in enumerate(performerlist):
            #创建模型
            model1=MoviePerformerItem()
            model1['id']=moviemodel['id']
            model1['performer']=performer
            try:
                if len(performerlist) == len(rolelist):
                    #去掉字符串中的'这个字符，替换为空格，否则sql会报错
                    role=rolelist[index].replace("'",' ')
                    model1['role'] = role
                else:
                    model1['role'] = ''
            except:
                print("演员饰演角色出错")

            yield model1

    def performerdetail(self,respose):
        name=respose.xpath("//h1[@itemprop='name']/text()").extract_first()
        jobtitle=respose.xpath("normalize-space(//li[@itemprop='jobTitle']/text())").extract_first()
        width=respose.xpath("normalize-space(//li[@itemprop='weight']/text())").extract_first()
        imagePath=respose.xpath("//img[@itemprop='image']/@src").extract_first()
        des=respose.xpath("//p[@class='introduce-info']/text()").extract_first()
        #左边
        lefts=respose.xpath("//dl[@class='basicInfo-block basicInfo-left']/dd/text()").extract()
        rights=respose.xpath("//dl[@class='basicInfo-block basicInfo-right']/dd/text()").extract()
        #组装数据
        #name e_name sex height birthday location school fameyear
        #alias bloodtype address constellation ResidentialAddress BrokerageAgency
        #hobby Occupation weight image des
        item=PerformerDetailTableItem()
        item['name']=name.replace("'",' ')
        item['e_name']=lefts[0].strip().replace("'",' ')
        item['alias']=rights[0].strip().replace("'",' ')
        item['sex']=lefts[1].strip()
        item['bloodtype']=rights[1].strip()
        item['height']=lefts[2].strip()
        item['location']=rights[2].strip().replace("'",' ')
        item['birthday']=lefts[3].strip()
        item['constellation']=rights[3].strip().replace("'",' ')
        item['address']=lefts[4].strip().replace("'",' ')
        item['ResidentialAddress']=rights[4].strip().replace("'",' ')
        item['school']=lefts[5].strip().replace("'",' ')
        item['BrokerageAgency']=rights[5].strip()
        item['fameyear']=lefts[6].strip()
        item['hobby']=rights[6].strip()

        item['weight']=width
        item['Occupation']=jobtitle
        item['imagePath'] = imagePath
        item['Occupation'] = jobtitle
        item['des'] = des.replace("'",' ')
        yield item








