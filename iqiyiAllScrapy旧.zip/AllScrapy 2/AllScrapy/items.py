# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class AllscrapyItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass
class CateGroyMovieItem(scrapy.Item):
    title=scrapy.Field()
    url=scrapy.Field()
    categroy=scrapy.Field()
    source=scrapy.Field()
    numid=scrapy.Field()

class MovieTableItem(scrapy.Item):
    movieName=scrapy.Field()
    url = scrapy.Field()
    time = scrapy.Field()
    score = scrapy.Field()
    imagePath = scrapy.Field()
    source = scrapy.Field()
    id = scrapy.Field()
    saveImagePath=scrapy.Field()

class MovieDetailTableItem(scrapy.Item):
    id=scrapy.Field()
    director=scrapy.Field()
    keyword=scrapy.Field()
    categroy=scrapy.Field()
    des=scrapy.Field()
class MoviePerformerItem(scrapy.Item):
    id=scrapy.Field()
    performer=scrapy.Field()
    role=scrapy.Field()
class PerformerDetailTableItem(scrapy.Item):
        name = scrapy.Field()
        e_name = scrapy.Field()
        sex = scrapy.Field()
        height = scrapy.Field()
        birthday = scrapy.Field()
        location = scrapy.Field()
        school = scrapy.Field()
        fameyear = scrapy.Field()
        alias = scrapy.Field()
        bloodtype = scrapy.Field()
        address = scrapy.Field()
        constellation = scrapy.Field()
        ResidentialAddress = scrapy.Field()
        BrokerageAgency = scrapy.Field()
        hobby = scrapy.Field()
        Occupation = scrapy.Field()
        weight = scrapy.Field()
        imagePath = scrapy.Field()
        des = scrapy.Field()
        saveImagePath = scrapy.Field()
