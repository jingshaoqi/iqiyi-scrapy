# -*- coding: utf-8 -*-

# Scrapy settings for AllScrapy project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://doc.scrapy.org/en/latest/topics/settings.html
#     https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://doc.scrapy.org/en/latest/topics/spider-middleware.html
import os
BOT_NAME = 'AllScrapy'
SPIDER_MODULES = ['AllScrapy.spiders']
NEWSPIDER_MODULE = 'AllScrapy.spiders'
#数据库的配置文件
HOST='127.0.0.1'
USERNAME='root'
PASSWORD='123'
DATABASE='MovieSpider'
PORT=3306
#默认用户
DEFAUL_USERID='149393437'


#分类信息地址
CATEGROYURL='http://list.iqiyi.com/www/1/----------------iqiyi--.html'
#分类资源名
IQIYISOURCE='iqiyi'
#图片下载文件夹
PHOTOPICTURE='/photo/'
#配置下载路径
DOWNLOADPATH='/Users/apple/Desktop/MySpider/Source'

# 过期天数
#IMAGES_EXPIRES = 90  #90天内抓取的都不会被重抓
#固定字段，setting中配置的下载路径
#IMAGES_STORE = '/Users/apple/Desktop/Source/'   #存储图片的文件夹位置
IMAGES_URLS_FIELD = "front_image_url"
# 获取当前文件路径
project_dir = os.path.abspath(os.path.dirname(__file__))
# 设置图片保存路径
IMAGES_STORE = os.path.join(project_dir, 'Source')
#保存封面地址
HEADERIMAGE = 'HEADERIMAGE/'
#阿里云图片上传地址
ACCESSKEYID = ''
ACCESSKEYSECRET = ''
ENDPOINT = 'oss-cn-shanghai.aliyuncs.com'
BUCKET = 'zcpicture'

# Crawl responsibly by identifying yourself (and your website) on the user-agent
#USER_AGENT = 'AllScrapy (+http://www.yourdomain.com)'
# Obey robots.txt rules
ROBOTSTXT_OBEY = True
# Configure maximum concurrent requests performed by Scrapy (default: 16)
#CONCURRENT_REQUESTS = 32

# Configure a delay for requests for the same website (default: 0)
# See https://doc.scrapy.org/en/latest/topics/settings.html#download-delay
# See also autothrottle settings and docs
#设置下载间隔
DOWNLOAD_DELAY = 0.25
# The download delay setting will honor only one of:
#CONCURRENT_REQUESTS_PER_DOMAIN = 16
#CONCURRENT_REQUESTS_PER_IP = 16

# Disable cookies (enabled by default)
#COOKIES_ENABLED = False

# Disable Telnet Console (enabled by default)
#TELNETCONSOLE_ENABLED = False

# Override the default request headers:
#DEFAULT_REQUEST_HEADERS = {
#   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
#   'Accept-Language': 'en',
#}

# Enable or disable spider middlewares
# See https://doc.scrapy.org/en/latest/topics/spider-middleware.html
#SPIDER_MIDDLEWARES = {
#    'AllScrapy.middlewares.AllscrapySpiderMiddleware': 543,
#}

# Enable or disable downloader middlewares
# See https://doc.scrapy.org/en/latest/topics/downloader-middleware.html
#配置请求头
DOWNLOADER_MIDDLEWARES = {
   'AllScrapy.middlewares.RotateUserAgentMiddleware': 543,
}
#处理代理ip
#'AllScrapy.middlewares.ProxyMiddleWare':544

# 'AllScrapy.middlewares.AllscrapyDownloaderMiddleware': 543,

# Enable or disable extensions
# See https://doc.scrapy.org/en/latest/topics/extensions.html
#EXTENSIONS = {
#    'scrapy.extensions.telnet.TelnetConsole': None,
#}

# Configure item pipelines
# See https://doc.scrapy.org/en/latest/topics/item-pipeline.html
ITEM_PIPELINES = {
   'AllScrapy.pipelines.CateGroyPipeLine': 300,
   'AllScrapy.pipelines.MoviePipeLine': 301,
   'AllScrapy.pipelines.MovieDetailPipeLine': 302,
   'AllScrapy.pipelines.MoviePerformerPipeLine': 303,
   'AllScrapy.pipelines.PerformerDetailPipeLine': 304,
   'AllScrapy.pipelines.DownloadPipeline': 305,
}
#AliyunOSSPipline

# Enable and configure the AutoThrottle extension (disabled by default)
# See https://doc.scrapy.org/en/latest/topics/autothrottle.html
#AUTOTHROTTLE_ENABLED = True
# The initial download delay
#AUTOTHROTTLE_START_DELAY = 5
# The maximum download delay to be set in case of high latencies
#AUTOTHROTTLE_MAX_DELAY = 60
# The average number of requests Scrapy should be sending in parallel to
# each remote server
#AUTOTHROTTLE_TARGET_CONCURRENCY = 1.0
# Enable showing throttling stats for every response received:
#AUTOTHROTTLE_DEBUG = False

# Enable and configure HTTP caching (disabled by default)
# See https://doc.scrapy.org/en/latest/topics/downloader-middleware.html#httpcache-middleware-settings
#HTTPCACHE_ENABLED = True
#HTTPCACHE_EXPIRATION_SECS = 0
#HTTPCACHE_DIR = 'httpcache'
#HTTPCACHE_IGNORE_HTTP_CODES = []
#HTTPCACHE_STORAGE = 'scrapy.extensions.httpcache.FilesystemCacheStorage'
