#coding:utf8
from  scrapy.cmdline import execute
execute(['scrapy','crawl','iqiyi'])
#pip3 install Pillow
#pip3 install mysql-connector-python
#pip3 install beautifulsoup4
#pip3 install requests
#pip3 install fake-useragent
#pip3 install oss2
#创建工程scrapy startproject AllScrapy
#创建模板scrapy genspider -t basic  mmonly mmonly.cc
